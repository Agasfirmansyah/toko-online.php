	<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen" />
	<link rel="stylesheet" href="css/custom-nivo-slider.css" type="text/css" media="screen" />
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/jquery.nivo.slider.pack.js" type="text/javascript"></script>
	<script type="text/javascript">
	$(window).load(function() {
		$('#slider').nivoSlider();
	});
	</script>
	<div id="slider">
		<img src="images/images_article/142.jpg" alt="" />
        <img src="images/images_article/108.jpg" alt="" />
        <img src="images/images_article/101.jpg" alt="" />
	</div>